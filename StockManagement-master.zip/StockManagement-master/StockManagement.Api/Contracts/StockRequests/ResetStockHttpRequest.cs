namespace StockManagement.Api.Contracts.StockRequests
{
    public class ResetStockHttpRequest
    {
        public string CorrelationId { get; set; }
    }
}