namespace StockManagement.Api.Contracts.ProductRequests
{
    public class PostProductHttpRequest
    {
        public string ProductCode { get; set; }
    }
}