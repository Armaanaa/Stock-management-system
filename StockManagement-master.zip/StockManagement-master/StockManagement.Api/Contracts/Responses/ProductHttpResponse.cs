namespace StockManagement.Api.Contracts.Responses
{
    public class ProductHttpResponse
    {
        public long ProductId { get; set; }
        public string ProductCode { get; set; }
    }
}