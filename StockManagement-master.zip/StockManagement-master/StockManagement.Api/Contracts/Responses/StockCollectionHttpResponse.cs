namespace StockManagement.Api.Contracts.Responses
{
    public class StockCollectionHttpResponse : BaseCollectionHttpResponse<StockHttpResponse>
    {
    }
}