namespace StockManagement.Api.Contracts.Responses
{
    public class ProductCollectionHttpResponse : BaseCollectionHttpResponse<ProductHttpResponse>
    {
    }
}