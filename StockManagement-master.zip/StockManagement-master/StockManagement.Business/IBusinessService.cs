namespace StockManagement.Business
{
    public interface IBusinessService
    {
    }
}