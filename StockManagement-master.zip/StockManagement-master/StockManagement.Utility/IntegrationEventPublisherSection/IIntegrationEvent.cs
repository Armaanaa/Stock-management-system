namespace StockManagement.Utility.IntegrationEventPublisherSection
{
    public interface IIntegrationEvent
    {
    }
}